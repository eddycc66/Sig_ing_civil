# -*- coding: utf-8 -*-

def classFactory(iface):
    from .plugin import CostoDistanciaPlugin
    return CostoDistanciaPlugin(iface)
