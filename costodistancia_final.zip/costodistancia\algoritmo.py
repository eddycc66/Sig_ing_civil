# -*- coding: utf-8 -*-

import numpy as np
import heapq
from osgeo import gdal
from qgis.core import (QgsProcessing,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterRasterLayer,
                       QgsProcessingParameterNumber,
                       QgsProcessingParameterFeatureSource,
                       QgsProcessingParameterBoolean,
                       QgsProcessingParameterVectorDestination,
                       QgsProcessingException,
                       QgsFeature,
                       QgsGeometry,
                       QgsPointXY,
                       QgsLineString,
                       QgsFields,
                       QgsField,
                       QgsVectorLayer,
                       QgsVectorFileWriter,
                       QgsWkbTypes)
from qgis.PyQt.QtCore import QVariant

class CostoDistanciaAlgorithm(QgsProcessingAlgorithm):
    INPUT_COST_RASTER = 'INPUT_COST_RASTER'
    INPUT_RASTER_BAND = 'INPUT_RASTER_BAND'
    INPUT_START_LAYER = 'INPUT_START_LAYER'
    INPUT_END_LAYER = 'INPUT_END_LAYER'
    ALL_ENDS = 'BOOLEAN_FIND_LEAST_PATH_TO_ALL_ENDS'
    LINEAR_REF = 'BOOLEAN_OUTPUT_LINEAR_REFERENCE'
    OUTPUT = 'OUTPUT'

    def tr(self, string):
        return string

    def createInstance(self):
        return CostoDistanciaAlgorithm()

    def name(self):
        return 'leastcostpath'

    def displayName(self):
        return self.tr('Costodistancia - Least Cost Path')

    def group(self):
        return self.tr('Análisis de Costos')

    def groupId(self):
        return 'analisis_costos'

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT_COST_RASTER, self.tr('Raster de costo')))
        self.addParameter(QgsProcessingParameterNumber(self.INPUT_RASTER_BAND, self.tr('Banda del raster'), type=QgsProcessingParameterNumber.Integer, defaultValue=1))
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_START_LAYER, self.tr('Capa de inicio (Puntos)'), [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_END_LAYER, self.tr('Capa de fin (Puntos)'), [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterBoolean(self.ALL_ENDS, self.tr('Calcular hacia todos los destinos'), defaultValue=False))
        self.addParameter(QgsProcessingParameterBoolean(self.LINEAR_REF, self.tr('Salida como referencia lineal (Ignorado en esta version)'), defaultValue=False))
        self.addParameter(QgsProcessingParameterVectorDestination(self.OUTPUT, self.tr('Capa vectorial de la ruta óptima')))

    def processAlgorithm(self, parameters, context, feedback):
        raster_layer = self.parameterAsRasterLayer(parameters, self.INPUT_COST_RASTER, context)
        band_num = self.parameterAsInt(parameters, self.INPUT_RASTER_BAND, context)
        start_source = self.parameterAsSource(parameters, self.INPUT_START_LAYER, context)
        end_source = self.parameterAsSource(parameters, self.INPUT_END_LAYER, context)

        if not raster_layer or not start_source or not end_source:
             raise QgsProcessingException("Entradas inválidas.")

        # Read Raster via GDAL
        ds = gdal.Open(raster_layer.source())
        band = ds.GetRasterBand(band_num)
        cost_array = band.ReadAsArray().astype(np.float32)
        geotransform = ds.GetGeoTransform()
        
        # Handle NoData
        nodata = band.GetNoDataValue()
        if nodata is not None:
            cost_array[cost_array == nodata] = np.inf
        cost_array[cost_array < 0] = np.inf # Simple friction check

        def world_to_pixel(x, y):
            x_idx = int((x - geotransform[0]) / geotransform[1])
            y_idx = int((y - geotransform[3]) / geotransform[5])
            return y_idx, x_idx

        def pixel_to_world(py, px):
            wx = geotransform[0] + px * geotransform[1] + py * geotransform[2] + 0.5 * geotransform[1]
            wy = geotransform[3] + px * geotransform[4] + py * geotransform[5] + 0.5 * geotransform[5]
            return wx, wy

        # Get Points
        start_feat = next(start_source.getFeatures())
        end_feat = next(end_source.getFeatures())
        
        start_y, start_x = world_to_pixel(start_feat.geometry().asPoint().x(), start_feat.geometry().asPoint().y())
        end_y, end_x = world_to_pixel(end_feat.geometry().asPoint().x(), end_feat.geometry().asPoint().y())

        rows, cols = cost_array.shape
        if not (0 <= start_x < cols and 0 <= start_y < rows) or not (0 <= end_x < cols and 0 <= end_y < rows):
            raise QgsProcessingException("Los puntos están fuera del raster.")

        # Dijkstra
        feedback.pushInfo("Ejecutando Dijkstra nativo...")
        dist = np.full((rows, cols), np.inf, dtype=np.float32)
        prev = {}
        dist[start_y, start_x] = 0
        pq = [(0, start_y, start_x)]
        
        found = False
        while pq:
            d, y, x = heapq.heappop(pq)
            
            if d > dist[y, x]: continue
            if y == end_y and x == end_x:
                found = True
                break
                
            for dy, dx in [(-1,0), (1,0), (0,-1), (0,1), (-1,-1), (-1,1), (1,-1), (1,1)]:
                ny, nx = y + dy, x + dx
                if 0 <= ny < rows and 0 <= nx < cols:
                    weight = cost_array[ny, nx]
                    if weight == np.inf: continue
                    
                    move_cost = weight * (1.414 if dy != 0 and dx != 0 else 1.0)
                    new_dist = d + move_cost
                    if new_dist < dist[ny, nx]:
                        dist[ny, nx] = new_dist
                        prev[(ny, nx)] = (y, x)
                        heapq.heappush(pq, (new_dist, ny, nx))

        if not found:
            raise QgsProcessingException("No se encontró una ruta posible.")

        # Reconstruct Path
        feedback.pushInfo("Reconstruyendo ruta...")
        path_points = []
        curr = (end_y, end_x)
        while curr in prev:
            wx, wy = pixel_to_world(curr[0], curr[1])
            path_points.append(QgsPointXY(wx, wy))
            curr = prev[curr]
        # Add start point
        wx, wy = pixel_to_world(start_y, start_x)
        path_points.append(QgsPointXY(wx, wy))

        # Create Output Vector
        fields = QgsFields()
        fields.append(QgsField("cost", QVariant.Double))
        
        sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, fields, QgsWkbTypes.LineString, raster_layer.crs())
        
        feature = QgsFeature()
        feature.setGeometry(QgsGeometry.fromPolylineXY(path_points))
        feature.setAttributes([float(dist[end_y, end_x])])
        sink.addFeature(feature)

        return {self.OUTPUT: dest_id}
