# -*- coding: utf-8 -*-

from qgis.core import QgsProcessingProvider
from .algoritmo import CostoDistanciaAlgorithm
from qgis.PyQt.QtGui import QIcon
import os

class CostoDistanciaProvider(QgsProcessingProvider):

    def __init__(self):
        QgsProcessingProvider.__init__(self)

    def unload(self):
        pass

    def loadAlgorithms(self):
        self.addAlgorithm(CostoDistanciaAlgorithm())

    def id(self):
        return 'costodistancia_provider'

    def name(self):
        return self.tr('Análisis de Costos')

    def icon(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        if os.path.exists(icon_path):
            return QIcon(icon_path)
        return QgsProcessingProvider.icon(self)

    def tr(self, string):
        return string
